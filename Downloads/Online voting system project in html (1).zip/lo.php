<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

	<title>result</title>

</head>
<body> 
       
   </div>

   	
   
    <marquee><h1> Result</h1></marquee>
    <center><img src="uu.png"width="300px" height="400px"></center>
           
  
</body>

</html>
	
<style>




		
</style>