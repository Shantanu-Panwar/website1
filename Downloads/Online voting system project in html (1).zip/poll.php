<!DOCTYPE html>
<html>
<head>
	<title>Ques For Vote</title>
	<link rel="stylesheet" type="text/css" href="bb.css">
</head>
<body>
	<marquee><h><b>Question Poll</h></b></marquee>
	<CENTER><br/>
		<h1>Poll Questions For User</h1>
	<div class="form-group">
						
     <div id="check">
    	<br>
    	
	
		<div style="position:relative;height:80px;">
		<label for="in">Date of vote:</label> &nbsp;&nbsp;&nbsp;&nbsp;
            		<input id="calendar" name="in" placeholder="2020-12-10" required="" type="text"> <br><br>
		
		
		
		</div>
		    1.	Who is Your Fav. Teacher:
                <select name="cake">
                    <option value="shivu">shivu</option>
        			<option value="saurabh">saurabh</option>
        			<option value="ritu">ritu</option>
					<option value="komal">komal</option>
                    <option value="rohit">rohit</option>
                </select>
                <div>
                	<br>&nbsp;
               2.  Who is topper of the class:
                <select name="cake">
                    <option value="shubham">shubham</option>
        			<option value="mukesh">mukesh</option>
        			<option value="rajesh">rajesh</option>
					<option value="dev">dev</option>
                    <option value="vishnu">vishnu</option>
                </select>
           
        </div>
        <div>
                	<br>&nbsp;
               3.  How was the college:
                <select name="cake">
                    <option value="Good">good</option>
        			<option value="medium">medium</option>
        			<option value="excellent">excellent</option>
					
                </select>
           
        </div>&nbsp; &nbsp;
                    
                
		<br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<a href="log.php"> <input type="submit" name="submit" value="submit" /></a>
		<a href="poll.php"> <input type="reset" name="reset" value="Reset" /></a>
	</CENTER>
	</form>
</div>
</body>
</html>