<!DOCTYPE html>
<html>
<head>
	<title>one page website</title>
	<link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>
	<div class="bgimage">
     <div class="menu">
     	<div class="leftmenu">
     	<h4>Online College Voting System</h4>
     </div>
     <div class="rightmenu">
     	<ul>
     		<li id="firstlist"><a href="index.php">home</li></a>
               
               <li><a href="poll.php">Add Poll</li></a>
     		
     		
     		
        <li><a href="log.php">Logout</li></a>

     	</ul>



     	</div>

     	
     </div>
     <div class="text">
             
               <h5>
                    Welcome to our site! 
               </h5>
               <h1>
                    IT'S NICE TO MEET YOU
              </h1>
              <h2>
              	WELCOME TO ONLINE VOTING!!!!
              </h2>
              <center>
         <a href="aa.php "><input type="submit"class ="btn btn-primary" name="submit" value="Login to admin"</a>

          <a href="pp.php"><input type="submit"class ="btn btn-primary" name="submit" value="Login to user"</a><br/>
            
          
      </center>


       </div>
     </div>     
                 

          
         
            
          </div>
         
 </body>
</html>