<!DOCTYPE html>
<html>
<head>
	<title>LogOut</title>
	

</head>
<body>
	<marquee><h><b>LogOut</h></b></marquee>
	<CENTER><br/><br><br>
	<center>
         <h1> Thanks for Attempt</h1>
	   <br><br>
		Feedback <label><textarea name=message></textarea></label>
		<div>
			<br><br>
		<a href="log.php "><input type="submit"class ="btn btn-primary" name="submit" value="submit"</a><br><br>
		 <a href="index.html "><input type="submit"class ="btn btn-primary" name="submit" value="LogOut"</a>
		
	</div>


		
		
	</div>
</center>
	</div>

		
	</div>
	
</body>
</html>
<style>
	body{
		background-image: url(ll.jpg);
		background-size: cover;
	}
	</style>