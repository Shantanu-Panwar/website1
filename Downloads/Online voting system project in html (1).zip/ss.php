
  


<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="log.css">
	<title></title>

</head>
<body> 
  
   <div class="container">
    <form action="aa.php"method="post" name="Signin" >
 <marquee>  <h1 class="text-center">SIGNIN</h1></marquee>

     
         <div class="input-group">
         
          <div class="col-sm-5 >
            <label for="Email">Email:-</label>
            <input type="email" name="email" class="form-control" placeholder="Email" required>
         </div>
     
        <div class="input-group">
          <div class="col-sm-5">
            <label for="Password">Password:-</label>
            <input type="password" name="password" class="form-control" placeholder="Password" required>
        </div>
     </div>
  
       
         <div class="col-sm-5"><br>
        <a href="aa.php"><button type="submit" class="btn btn-primary">Signin</button></a>
    </div>
    
         
    

   </div>
 </div>
</form>
   		
</body>

</html>






		
