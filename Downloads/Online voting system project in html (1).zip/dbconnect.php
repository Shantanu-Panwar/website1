<?php
$db_host="localhost";
$db_username="shivani";
$db_password="kashyap";
$db_name="priyaa";

 
$conn=mysqli_connect($db_host,$db_username,$db_password,$db_name);
if ($conn)
{
  echo"sucessful";
}
  else {
        echo"failed";
}
?>